# User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Object** | Id autogenerado del actor |  [optional]
**username** | **Object** |  |  [optional]
**email** | **Object** |  |  [optional]
**password** | **Object** |  |  [optional]
**createdDate** | **Object** |  |  [optional]
**lastLoginDate** | **Object** |  |  [optional]
