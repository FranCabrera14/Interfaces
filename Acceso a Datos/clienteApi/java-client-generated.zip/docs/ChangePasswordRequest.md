# ChangePasswordRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **Object** |  | 
**oldPassword** | **Object** |  | 
**newPassword** | **Object** |  | 
